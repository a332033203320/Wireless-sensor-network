/****************************************************************************
 *
 * MODULE:             serialq.h
 *
 * COMPONENT:          $RCSfile: serialq.h,v $
 *
 * VERSION:            $Name:  $
 *
 * REVISION:           $Revision: 1.1.1.1 $
 *
 * DATED:              $Date: 2007/04/18 03:10:39 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Ian Morris
 *
 * DESCRIPTION
 *
 * CHANGE HISTORY:
 *
 * $Log: serialq.h,v $
 * Revision 1.1.1.1  2007/04/18 03:10:39  isaac_tung
 * no message
 *
 * Revision 1.1  2006/08/24 14:58:59  imorr
 * Initial version
 *
 *
 *
 * LAST MODIFIED BY:   $Author: isaac_tung $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 *  (c) Copyright 2000 JENNIC Ltd
 *
 ****************************************************************************/


#ifndef  SERIAL_Q_H_INCLUDED
#define  SERIAL_Q_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

/****************************************************************************/
/***        Include Files                                                 ***/
/****************************************************************************/
#include <jendefs.h>

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/
typedef enum {RX_QUEUE = 0, TX_QUEUE } eQueueRef;
/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/
PUBLIC void   vSerialQ_Init(void);
PUBLIC bool_t bSerialQ_Full(eQueueRef eQueue);
PUBLIC bool_t bSerialQ_Empty(eQueueRef eQueue);
PUBLIC uint8  u8SerialQ_RemoveItem(eQueueRef eQueue);
PUBLIC void   vSerialQ_AddItem(eQueueRef eQueue, uint8 u8Item);

PUBLIC bool bSerialQ_State(void);
/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

#if defined __cplusplus
}
#endif

#endif  /* SERIAL_Q_H_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


