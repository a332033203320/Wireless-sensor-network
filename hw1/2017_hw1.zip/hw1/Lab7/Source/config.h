/****************************************************************************
 *
 * MODULE:             config.h
 *
 * COMPONENT:          $RCSfile: config.h,v $
 *
 * VERSION:            $Name:  $
 *
 * REVISION:           $Revision: 1.1.1.1 $
 *
 * DATED:              $Date: 2007/04/18 03:10:39 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Ian Morris
 *
 * DESCRIPTION
 *
 * CHANGE HISTORY:
 *
 * $Log: config.h,v $
 * Revision 1.1.1.1  2007/04/18 03:10:39  isaac_tung
 * no message
 *
 * Revision 1.1  2006/08/24 14:59:31  imorr
 * Initial version
 *
 *
 *
 * LAST MODIFIED BY:   $Author: isaac_tung $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 *  (c) Copyright 2000 JENNIC Ltd
 *
 ****************************************************************************/


#ifndef  CONFIG_H_INCLUDED
#define  CONFIG_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

/****************************************************************************/
/***        Include Files                                                 ***/
/*******************MAX_UART_NODES*********************************************************/
#include <jendefs.h>

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
#define LED1_MASK               (1<<8)
#define LED2_MASK               (1<<9)
#define LED_OUTPUTS_MASK        (LED1_MASK | LED2_MASK)


/* Network parameters */
#define PAN_ID                  0x0401U
#define COORD_ADDR              0x0502U            //1282

/* Wireless UART device data */
#define MAX_UART_NODES          10
#define UART_NODE_ADDR_BASE     0x1000U         //4096
#define MAX_DATA_PER_FRAME      64

#define TICK_PERIOD_ms          20UL
#define TICK_PERIOD_COUNT       (16000UL * TICK_PERIOD_ms)

/* Defines the channels to scan. Each bit represents one channel. All channels
   in the channels (11-26) in the 2.4GHz band are scanned. */
#define SCAN_CHANNELS           0x07FFF800UL
#define CHANNEL_MIN             11
#define ACTIVE_SCAN_DURATION    3
#define ENERGY_SCAN_DURATION    3 /* Duration (ms) = ((960 * (2^ENERGY_SCAN_DURATION + 1)) / 62.5) */

/* Define which of the two available hardware UARTs and what baud rate to use */
//#ifdef ROLE_COORD
//    #define UART                    E_AHI_UART_1
//#else
    #define UART                    E_AHI_UART_0
//#endif

#define TICKER_PERIOD       (16*1000*1000)        //1000ms
/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

#if defined __cplusplus
}
#endif

#endif  /* CONFIG_H_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


