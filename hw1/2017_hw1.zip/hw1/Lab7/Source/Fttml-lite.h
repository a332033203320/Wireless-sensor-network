#include <jendefs.h>

#ifndef FTTML_LITE_H_INCLUDED
#define FTTML_LITE_H_INCLUDED


/****************************************************************************/
/***        Include Files                                                 ***/
/****************************************************************************/

#include "config.h"
#include <Utilities.h>

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/
#define MAX_OF_CONNECT MAX_UART_NODES


// ==== define recvice sequence number
#define FT_RECV_SEQ_NO_ERROR	0x00
#define FT_RECV_SEQ_SAME		0x01
#define FT_RECV_SEQ_LESS		0x02

typedef struct t_SeqDef{
    uint8 u8SeqCnt					;//	= 0;
    uint16 u16SAddr[MAX_OF_CONNECT]	;//	= 0;
    uint8 u8LastSentSeq[MAX_OF_CONNECT];//	= 0;
    uint8 u8LastRecvSeq[MAX_OF_CONNECT];//	= 0;
} t_SeqDef;

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/
t_SeqDef theSeqList;


/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/
PUBLIC uint8	FtTML_GetNextSendSeq(uint16 u16SAddr);
PUBLIC uint8 	FtTML_CheckRecvSeq(uint16 u16SAddr, uint8 u8RecvSeq);
PUBLIC void     FtTML_ResetSeq(uint16 u16SAddr);

#endif // FTTML_LITE_H_INCLUDED
