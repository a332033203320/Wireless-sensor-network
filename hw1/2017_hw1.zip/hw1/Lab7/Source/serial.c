/****************************************************************************
 *
 * MODULE:             uart.c
 *
 * COMPONENT:          $RCSfile: serial.c,v $
 *
 * VERSION:            $Name:  $
 *
 * REVISION:           $Revision: 1.1.1.1 $
 *
 * DATED:              $Date: 2007/04/18 03:10:39 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Ian Morris
 *
 * DESCRIPTION
 *
 * CHANGE HISTORY:
 *
 * $Log: serial.c,v $
 * Revision 1.1.1.1  2007/04/18 03:10:39  isaac_tung
 * no message
 *
 * Revision 1.1  2006/08/24 14:59:26  imorr
 * Initial version
 *
 *
 *
 * LAST MODIFIED BY:   $Author: isaac_tung $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 *  (c) Copyright 2000 JENNIC Ltd
 *
 ****************************************************************************/

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
#include <jendefs.h>
#include <AppHardwareApi.h>

#include "uart.h"
#include "serialq.h"
#include "serial.h"

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
#define TX_STRING_END_CHAR   '\0'    /* Strings to be transmitted must end with NULL */
#define RX_STRING_END_CHAR   CR_CHAR /* Input string must end with carriage return */

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

/****************************************************************************
 *
 * NAME: vSerial_Init
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerial_Init(void)
{
    /* Initialise the serial port and rx/tx queues */
    vUART_Init();
    vSerialQ_Init();
}

/****************************************************************************
 *
 * NAME: vSerial_TxChar
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerial_TxChar(uint8 u8Chr)
{
    if(!bSerialQ_Full(TX_QUEUE))
    {
        vSerialQ_AddItem(TX_QUEUE, u8Chr);
        vUART_StartTx();      /* Start the tx process if it has stalled */
	}
}

/****************************************************************************
 *
 * NAME: vSerial_TxString
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerial_TxString(const uint8 *ps)
{
    const uint8 *pu8String;

	/* Copy the string to be transmitted to the transmit queue */

    for(pu8String = ps; (!bSerialQ_Full(TX_QUEUE) && (*pu8String != TX_STRING_END_CHAR)); pu8String++)
    {
        vSerialQ_AddItem(TX_QUEUE, *pu8String);  /* Add character to the transmit queue. */
    }
    vUART_StartTx();      /* Start the tx process if it has stalled */
}

/****************************************************************************
 *
 * NAME: i16Serial_RxChar
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC int16 i16Serial_RxChar(void)
{
    int16 i16Result = -1;

    if(!bSerialQ_Empty(RX_QUEUE))
	{
   	    i16Result = u8SerialQ_RemoveItem(RX_QUEUE);
	}
    return(i16Result);
}

/****************************************************************************
 *
 * NAME: vSerial_Init
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerialRxString(uint8 *ps)
{
    uint8 *pu8String;
	int16 i16Chr;

    /* Copy the received string from the receive queue */

    for(pu8String = ps; ((i16Chr = i16Serial_RxChar()) != (int16)RX_STRING_END_CHAR); pu8String++)
    {
        *pu8String = (uint8)i16Chr;
    }

    *pu8String = (uint8)'\0'; /* Append NULL character to the end of the string */
}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
