#include "Fttml-lite.h"


PUBLIC uint8	FtTML_GetNextSendSeq(uint16 u16SAddr)
{
	uint8 rtnVal = 0;
	uint8 u8Ind = 0;
	for (u8Ind = 0; u8Ind < theSeqList.u8SeqCnt; u8Ind++)
    {
    	if (memcmp(&(theSeqList.u16SAddr[u8Ind]),&u16SAddr,2) == 0)
        {
        	if (theSeqList.u8LastSentSeq[u8Ind] == 0xFF)
            {
            	rtnVal = theSeqList.u8LastSentSeq[u8Ind];
                theSeqList.u8LastSentSeq[u8Ind] = 0;
            }
            else
        		rtnVal = theSeqList.u8LastSentSeq[u8Ind]++;

            return rtnVal;
        }
    }

    theSeqList.u16SAddr[theSeqList.u8SeqCnt] = u16SAddr;
    rtnVal = theSeqList.u8LastSentSeq[theSeqList.u8SeqCnt]++;
    theSeqList.u8SeqCnt++;

    return rtnVal;

}

PUBLIC uint8 	FtTML_CheckRecvSeq(uint16 u16SAddr, uint8 u8RecvSeq)
{
	uint8 rtnVal = FT_RECV_SEQ_NO_ERROR;
    uint8 u8Ind = 0;

	for (u8Ind = 0; u8Ind < theSeqList.u8SeqCnt; u8Ind++)
    {
    	if (memcmp(&(theSeqList.u16SAddr[u8Ind]),&u16SAddr,2) == 0)
        {
        	if (theSeqList.u8LastRecvSeq[u8Ind] < u8RecvSeq)
        	{
            	theSeqList.u8LastRecvSeq[u8Ind] = u8RecvSeq;
				return FT_RECV_SEQ_NO_ERROR;
        	}
            else if (theSeqList.u8LastRecvSeq[u8Ind] > u8RecvSeq)
            {
            	if((theSeqList.u8LastRecvSeq[u8Ind] > 0xF0) && (u8RecvSeq < 0x10))
            	{
        			theSeqList.u8LastRecvSeq[u8Ind] = u8RecvSeq;
					return FT_RECV_SEQ_NO_ERROR;
            	}
                else
                   return FT_RECV_SEQ_LESS;

            }
            else
                return FT_RECV_SEQ_SAME;
        }
    }

	theSeqList.u16SAddr[theSeqList.u8SeqCnt] = u16SAddr;
	theSeqList.u8LastRecvSeq[theSeqList.u8SeqCnt] = u8RecvSeq;
	theSeqList.u8SeqCnt++;


    return rtnVal;
}

PUBLIC void     FtTML_ResetSeq(uint16 u16SAddr)
{
    uint8 u8Ind = 0;

    for (u8Ind = 0; u8Ind < theSeqList.u8SeqCnt; u8Ind++)
    {
        if (memcmp(&(theSeqList.u16SAddr[u8Ind]),&u16SAddr,2) == 0)
        {
        	theSeqList.u8LastRecvSeq[u8Ind] = 0;
        	theSeqList.u8LastSentSeq[u8Ind] = 0;
        }
    }
}
