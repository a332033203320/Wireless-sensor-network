#include "FontalIO.h"

#ifndef FT_DEBUG_H__
#define FT_DEBUG_H__

PUBLIC void vDebugInit(void);
PUBLIC void vDebugPrint(char * str);
PUBLIC void vDebugHex(uint32 hexData);
PUBLIC void vDebug8Hex(uint8 hexData);
PUBLIC void vDebugInt(uint32 intData);

#endif
