/*****************************************************************************
 *
 * MODULE:		Fontal Technology Inc. Evaluation Board Library
 * VERSION:		$Name:  $
 * REVISION:		$Revision: 1.1.1.1 $
 * DATED:		2006/11/28
 * AUTHOR:           Tony Lu
 * DESCRIPTION:
 * 	Macros to make it easier to use LED
 * LAST MODIFIED BY:    $Author: isaac_tung $
 * LAST MODIFIED DATE: $Date: 2007/02/02 03:01:12 $
 *
 ****************************************************************************
 *
 *  (c) Fontal Technology Inc. 2006
 *
 ****************************************************************************/


#ifndef _FontalLED_H
#define _FontalLED_H
#include <jendefs.h>

//Fontal Module Platform LED 
#define LED0	(1 << 8)
#define LED1  (1<<9)
#define LED_ALL (LED0|LED1)

//Fontal Support only one LED
void FtIO_LedInit(void);
void FtIO_LedOn(uint32 bitmap);
void FtIO_LedOff(uint32 bitmap);
void FtIO_LedToggle(uint32 bitmap);

#define led_init() \
		vAHI_DioSetDirection(0,LED_ALL)

#define led_on(bitmap) \
			vAHI_DioSetOutput(bitmap,0)

#define led_off(bitmap) \
			vAHI_DioSetOutput(0,bitmap)


#define led_toggle(bitmap)\
			vAHI_DioSetOutput((u32AHI_DioReadInput() & bitmap ) ^ bitmap, \
							(u32AHI_DioReadInput() & bitmap ) )

#endif


