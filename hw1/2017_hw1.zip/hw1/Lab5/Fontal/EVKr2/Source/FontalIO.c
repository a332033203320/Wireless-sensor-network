#include "FontalWtd.h"
#include "FontalIO.h"
#include <AppHardwareApi.h>

// circular queue uint8
typedef struct
{
	uint16	head;
	uint16	tail;
	uint16	length;
	uint8	data[1];
}__attribute__ ((packed)) cqu8_t;

void	cqu8_init	(cqu8_t *self, uint16 length);
void	cqu8_push	(cqu8_t *self, uint8 data);
void	cqu8_pop	(cqu8_t *self, uint8 *pData);
bool_t	cqu8_empty	(cqu8_t *self);
bool_t	cqu8_full	(cqu8_t *self);

#define FT_UART_RX_BUFFER_SIZE 128

uint8 uart0_rx_queue_buffer[sizeof(cqu8_t) - 1 + FT_UART_RX_BUFFER_SIZE];
cqu8_t *uart0_rx_queue = (cqu8_t *)uart0_rx_queue_buffer;

uint8 uart1_rx_queue_buffer[sizeof(cqu8_t) - 1 + FT_UART_RX_BUFFER_SIZE];
cqu8_t *uart1_rx_queue = (cqu8_t *)uart1_rx_queue_buffer;

void UartInterruptSetup(uint8 u8PortName,bool_t bEnable)
{
	vAHI_UartSetInterrupt(u8PortName,FALSE,FALSE,bEnable,bEnable,E_AHI_UART_FIFO_LEVEL_1);
}

#ifndef GDB
static void Uart0_interrupt_handler(uint32 u32Device, uint32 u32ItemBitmap)
{
	uint8 data;

	if(u32ItemBitmap==E_AHI_UART_INT_RXDATA)
	{
		data = u8AHI_UartReadData(E_AHI_UART_0);
		if(!cqu8_full(uart0_rx_queue))
			cqu8_push(uart0_rx_queue, data);
	}
}
#endif

static void Uart1_interrupt_handler(uint32 u32Device, uint32 u32ItemBitmap)
{
	uint8 data;

	if(u32ItemBitmap==E_AHI_UART_INT_RXDATA)
	{
		data = u8AHI_UartReadData(E_AHI_UART_1);
		if(!cqu8_full(uart1_rx_queue))
			cqu8_push(uart1_rx_queue, data);
	}
}

void FtIO_LedInit(void)
{
	uint32 DioOutput=0,DioInput=0;
	DioOutput=DioOutput|(LED_ALL);
	vAHI_DioSetDirection(DioInput,DioOutput);
	vAHI_DioSetPullup(0,DioOutput);
	vAHI_DioSetOutput(DioOutput,0);
}

void FtIO_UartInit(uint8 u8PortNumber, uint8 FtUartRate)
{
	uint8 u8PortName=0;
	cqu8_t * pcq_rx_queue=uart0_rx_queue;

	if(u8PortNumber==0)
	{
		u8PortName=E_AHI_UART_0;
		pcq_rx_queue=uart0_rx_queue;
	}
	else
	{
		u8PortName=E_AHI_UART_1;
		pcq_rx_queue=uart1_rx_queue;
	}
	vAHI_UartEnable(u8PortName);
	vAHI_UartReset(u8PortName, TRUE, TRUE);
	vAHI_UartSetClockDivisor(u8PortName, FtUartRate);
	vAHI_UartSetControl(u8PortName, FALSE, FALSE, E_AHI_UART_WORD_LEN_8, TRUE, FALSE);
	if(u8PortNumber==0)
	{

#ifndef GDB		
		vAHI_Uart0RegisterCallback(Uart0_interrupt_handler);
#endif
		
	}
	else
	{
		vAHI_Uart1RegisterCallback(Uart1_interrupt_handler);
	}
	UartInterruptSetup(u8PortName,TRUE);
	cqu8_init(pcq_rx_queue, FT_UART_RX_BUFFER_SIZE);
}

void	FtIO_UartWrite(uint8 PortNumber,uint8 *pdata, uint8 length)
{
	uint8 u8PortName=0;
	if(PortNumber==0)
	{
		u8PortName=E_AHI_UART_0;
	}
	else
	{
		u8PortName=E_AHI_UART_1;
	}
	while(length)
	{
		while((u8AHI_UartReadLineStatus(u8PortName) & E_AHI_UART_LS_THRE) == 0);
		vAHI_UartWriteData(u8PortName, *pdata++);
		--length;
	}
}

void	FtIO_UartPrint(uint8 PortNumber,const char *str)
{
	uint8 u8PortName=0;
	if(PortNumber==0)
		u8PortName=E_AHI_UART_0;
	else
		u8PortName=E_AHI_UART_1;

	if(str == 0 || *str == 0)
		return;

	while(*str != 0)
	{
		FtIO_UartWrite(u8PortName,(uint8*)str, 1);
		++str;
	}
}

uint8 FtIO_UartRead(uint8 PortNumber,uint8 *pdata, uint8 length)
{
	cqu8_t *rx_queue=NULL;
	uint8 u8PortName=0;
	uint8 read;
	if(PortNumber==0)
		{
		rx_queue=uart0_rx_queue;
		u8PortName=E_AHI_UART_0;
		}
	else
		{
		rx_queue=uart1_rx_queue;
		u8PortName=E_AHI_UART_1;
		}

	for(read = 0;
	!cqu8_empty(rx_queue) && read < length;
	++read)
	{
		UartInterruptSetup(u8PortName,FALSE);
		cqu8_pop(rx_queue, pdata + read);
		UartInterruptSetup(u8PortName,TRUE);
	}
	return read;
}

void	FtIO_UartDisable(uint8 PortNumber)
{
	if(PortNumber==0)
		{
		vAHI_UartDisable(E_AHI_UART_0);
		}
	else
		{
		vAHI_UartDisable(E_AHI_UART_1);
		}
}

void FtIO_LedOn(uint32 bitmap)
{
	vAHI_DioSetOutput(0, bitmap);
}

void FtIO_LedOff(uint32 bitmap)
{
	vAHI_DioSetOutput(bitmap, 0);
}

void FtIO_LedToggle(uint32 bitmap)
{
	uint32 on_bitmap;
	uint32 off_bitmap;

	off_bitmap = u32AHI_DioReadInput();
	off_bitmap &= bitmap;
	on_bitmap = off_bitmap ^ bitmap;
	vAHI_DioSetOutput(on_bitmap, off_bitmap);
	//vAHI_DioSetOutput(off_bitmap, on_bitmap);
}

void cqu8_init(cqu8_t *self, uint16 length)
{
	self->head = 0;
	self->tail = 0;
	self->length = length;
}

void cqu8_push(cqu8_t *self, uint8 data)
{
	if(!cqu8_full(self))
	{
		self->data[self->tail] = data;
		++self->tail;
		self->tail %= self->length;
	}
}

void cqu8_pop(cqu8_t *self, uint8 *pData)
{
	if(!cqu8_empty(self))
	{
		*pData = self->data[self->head];
		++self->head;
		self->head %= self->length;
	}
}

bool_t cqu8_empty(cqu8_t *self)
{
	return self->head == self->tail;
}

bool_t cqu8_full(cqu8_t *self)
{
	uint16 next = self->tail + 1;
	next %= self->length;
	return next == self->head;
}

void FtIO_ButtonInit(void)
{
	btn_init();
}

bool_t FtIO_ButtonPressed(uint8 u8ButtonNumber)
{
	if(u8ButtonNumber==0)
		return btn_pressed(BUTTON0);
	else
		return btn_pressed(BUTTON1);
}

void FtIO_ButtonDisalbe(uint8 u8ButtonNumber)
{
	if(u8ButtonNumber==0)
		vAHI_DioInterruptEnable(0, BUTTON0);
	else
		vAHI_DioInterruptEnable(0, BUTTON1);
}

void FtIO_WatchDogInit(void)
{
	wdt_init();
}

void FtIO_WatchDogTrigger(void)
{
	//wdt_reset();
	led_toggle(WDT);
}

