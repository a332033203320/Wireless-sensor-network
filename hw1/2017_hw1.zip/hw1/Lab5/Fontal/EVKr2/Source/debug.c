#include "debug.h"
#include <appHardwareapi.h>
#include <utilities.h>

#ifdef UART1_DEBUG
PUBLIC void vDebugInit(void)
{
	FtIO_UartInit(E_AHI_UART_1,E_AHI_UART_RATE_38400);
	
}

PUBLIC void vDebugPrint(char * str)
{
	FtIO_UartPrint(E_AHI_UART_1, str);
}

PUBLIC void vDebugHex(uint32 hexData)
{
	char  pcString[9];
	int i,j=0;
    uint8  u8Nybble;

    for (i = 28; i >= 0; i -= 4)
    {
        u8Nybble = (uint8)((hexData >> i) & 0x0f);
        u8Nybble += 0x30;
        if (u8Nybble > 0x39)
            u8Nybble += 7;

        pcString[j] = (char) u8Nybble;
        //pcString++;
        j++;
    }
    pcString[j] = 0;


	vDebugPrint(pcString);
}

PUBLIC void vDebug8Hex(uint8 hexData)
{
	char  pcString[3];
	int i,j=0;
    uint8  u8Nybble;

    for (i = 4; i >= 0; i -= 4)
    {
        u8Nybble = (uint8)((hexData >> i) & 0x0f);
        u8Nybble += 0x30;
        if (u8Nybble > 0x39)
            u8Nybble += 7;

        pcString[j] = (char) u8Nybble;
        //pcString++;
        j++;
    }
    pcString[j] = 0;


	vDebugPrint(pcString);
}

PUBLIC void vDebugInt(uint32 intData)
{
	char pcStr[11];
	uint8 base = 10;
	int i = 0;
	uint32 u32Val = intData;

	memset(pcStr, '\0',11);
	for (i = 10; i>=0; i--)
	{
		pcStr[i] = 0x30 + u32Val %base;
		u32Val /= base;
		if (u32Val == 0)
			break;
	}

	vDebugPrint(pcStr+(11-i));	
}
#else
PUBLIC void vDebugInit(void)
{}

PUBLIC void vDebugPrint(char * str)
{}

PUBLIC void vDebugHex(uint32 hexData)
{}

PUBLIC void vDebug8Hex(uint8 hexData)
{}

PUBLIC void vDebugInt(uint32 intData)
{}

#endif
