/****************************************************************************
 *
 * MODULE:             uart.c
 *
 * COMPONENT:          $RCSfile: serial.c,v $
 *
 * VERSION:            $Name: JN-AN-1005-1v7 $
 *
 * REVISION:           $Revision: 1.1 $
 *
 * DATED:              $Date: 2006/08/24 14:59:26 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Ian Morris
 *
 * DESCRIPTION
 *
 * CHANGE HISTORY:
 *
 * $Log: serial.c,v $
 * Revision 1.1  2006/08/24 14:59:26  imorr
 * Initial version
 *
 *
 *
 * LAST MODIFIED BY:   $Author: imorr $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 *  (c) Copyright 2000 JENNIC Ltd
 *
 ****************************************************************************/

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
#include <jendefs.h>
#include <AppHardwareApi.h>
#include <FontalLED.h>/

#include "uart.h"
#include "serialq.h"
#include "serial.h"

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
#define TX_STRING_END_CHAR   '\0'    /* Strings to be transmitted must end with NULL */
#define RX_STRING_END_CHAR   0x01U   /* Input string must end with carriage return */

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

/****************************************************************************
 *
 * NAME: vSerial_Init
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerial_Init(void)
{
    /* Initialise the serial port and rx/tx queues */
    vUART_Init();
    vSerialQ_Init();
}

/****************************************************************************
 *
 * NAME: vSerial_TxChar
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerial_TxChar(uint8 u8Chr)
{
    if(!bSerialQ_Full(TX_QUEUE))
    {
        vSerialQ_AddItem(TX_QUEUE, u8Chr);
        vUART_StartTx();      /* Start the tx process if it has stalled */
	}
}

/****************************************************************************
 *
 * NAME: vSerial_TxString
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerial_TxString(const uint8 *ps)
{
    const uint8 *pu8String;

	/* Copy the string to be transmitted to the transmit queue */
    for(pu8String = ps; (!bSerialQ_Full(TX_QUEUE) && (*pu8String != TX_STRING_END_CHAR)); pu8String++)
    {
        vSerialQ_AddItem(TX_QUEUE, *pu8String);  /* Add character to the transmit queue. */
    }
	vSerialQ_AddItem(TX_QUEUE, RX_STRING_END_CHAR);

    vUART_StartTx();      /* Start the tx process if it has stalled */
}

/****************************************************************************
 *
 * NAME: u8Serial_RxChar
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC uint8 u8Serial_RxChar(void)
{
    uint8 u8Result = RX_STRING_END_CHAR;

    if(!bSerialQ_Empty(RX_QUEUE))
	{
   	    u8Result = u8SerialQ_RemoveItem(RX_QUEUE);
	}

    return(u8Result);
}

/****************************************************************************
 *
 * NAME: vSerial_Init
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerialRxString(uint8 *ps)
{
    uint8 *pu8String;
	uint8 u8Chr;
    /* Copy the received string from the receive queue */
    for(pu8String = ps; ((u8Chr = u8Serial_RxChar()) != RX_STRING_END_CHAR); pu8String++)
    {
        *pu8String = u8Chr;
    }
    *pu8String = (uint8)TX_STRING_END_CHAR; /* Append NULL character to the end of the string */
}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
