#ifndef  UTILITY_H_INCLUDED
#define  UTILITY_H_INCLUDED

void vByteToHEX(unsigned char u8Data, char *pcString);
void v2ByteToDEC(unsigned short u16Data, char *pcString);
unsigned short u16DECTo2Byte(char *pcString);

#endif
