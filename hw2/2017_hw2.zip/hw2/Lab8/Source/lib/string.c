#include "string.h"

int strncmp(const char * cs,const char * ct,unsigned int count)
{
	register signed char __res = 0;

	while (count) {
		if ((__res = *cs - *ct++) != 0 || !*cs++)
			break;
		count--;
	}

	return __res;
}

char * strncat(char *dest, const char *src, unsigned int count)
{
	char *tmp = dest;

	if (count) {
		while (*dest)
			dest++;
		while ((*dest++ = *src++)) {
			if (--count == 0) {
				*dest = '\0';
				break;
			}
		}
	}

	return tmp;
}

char * strncpy(char *dest, const char *src, unsigned int count)
{
	if (count != 0) {
		char *d = dest;
		const char *s = src;

		do {
			if ((*d++ = *s++) == 0)
			{
				while (--count != 0)
					*d++ = 0;
				break;
			}
		} while (--count != 0);
	}
	return dest;
}

unsigned int strlen(const char *s)
{
	unsigned int i;

	i = 0;
	while (s[i] != 0)
		i++;

	return i;
}
