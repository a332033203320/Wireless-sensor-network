#include "utility.h"

void vByteToHEX(unsigned char u8Data, char *pcString)
{	
	unsigned char u8Byte = u8Data>>4; //u8Data���e�|��
	u8Byte += 0x30;
	if (u8Byte > 0x39)
		u8Byte += 7;
	*pcString=u8Byte;
	pcString++;

	u8Byte=u8Data&0x0f; //u8Data����|��
	u8Byte += 0x30;
	if (u8Byte > 0x39)
		u8Byte += 7;
	*pcString=u8Byte;
	pcString++;

	*pcString=0; //�̫��W
}

void v2ByteToDEC(unsigned short u16Data, char *pcString)
{
	signed char u8Ind = 4;
	do{
		pcString[u8Ind] = 0x30 + (u16Data%10) ;
		u16Data /= 10;
		u8Ind--;
	}
	while (u8Ind>=0);
	pcString[5] = '\0';
}

unsigned short u16DECTo2Byte(char *pcString)
{
	unsigned short u16Data = 0;
	signed char cInd = 0;
	while( pcString[cInd] <= 0x39 && pcString[cInd] >= 0x30){
		u16Data *= 10;
		u16Data += pcString[cInd] - 0x30;
		cInd++;
	}
	return u16Data;
}
