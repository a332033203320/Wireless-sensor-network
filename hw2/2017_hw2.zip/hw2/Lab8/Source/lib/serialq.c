/****************************************************************************
 *
 * MODULE:             uart.c
 *
 * COMPONENT:          $RCSfile: serialq.c,v $
 *
 * VERSION:            $Name: JN-AN-1005-1v7 $
 *
 * REVISION:           $Revision: 1.1 $
 *
 * DATED:              $Date: 2006/08/24 14:59:05 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Ian Morris
 *
 * DESCRIPTION
 *
 * CHANGE HISTORY:
 *
 * $Log: serialq.c,v $
 * Revision 1.1  2006/08/24 14:59:05  imorr
 * Initial version
 *
 *
 *
 * LAST MODIFIED BY:   $Author: imorr $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 *  (c) Copyright 2000 JENNIC Ltd
 *
 ****************************************************************************/

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
#include <jendefs.h>
#include <AppHardwareApi.h>

#include "serialq.h"

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
#define MAX_CIRCBUFF_SIZE   2048
#define NBR_QUEUES          2

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/
typedef struct
{
    uint8  u8Head;
    uint8  u8Tail;
    uint8  u8Count;
    uint8  u8Buff[MAX_CIRCBUFF_SIZE];
} tsCircBuff;

/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/
PRIVATE tsCircBuff sRxQueue, sTxQueue;
PRIVATE const tsCircBuff *apsQueueList[NBR_QUEUES] = { &sRxQueue, &sTxQueue };

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/
PRIVATE void vSerialQ_Flush(eQueueRef eQueue);

/****************************************************************************
 *
 * NAME: vSerialQ_Init
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerialQ_Init(void)
{
    vSerialQ_Flush(RX_QUEUE);
    vSerialQ_Flush(TX_QUEUE);
}

/****************************************************************************
 *
 * NAME: vSerialQ_AddItem
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC void vSerialQ_AddItem(eQueueRef eQueue, uint8 u8Item)
{
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    if(!bSerialQ_Full(eQueue))
    {
        psQueue->u8Buff[psQueue->u8Head] = u8Item;
        psQueue->u8Head = (psQueue->u8Head + 1) % MAX_CIRCBUFF_SIZE;
        psQueue->u8Count++;
    }
}

/****************************************************************************
 *
 * NAME: u8SerialQ_RemoveItem
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC uint8 u8SerialQ_RemoveItem(eQueueRef eQueue)
{
    uint8 u8Item = 0;
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    if(!bSerialQ_Empty(eQueue))
    {
        u8Item = psQueue->u8Buff[psQueue->u8Tail];
        psQueue->u8Tail = (psQueue->u8Tail + 1) % MAX_CIRCBUFF_SIZE;
        psQueue->u8Count--;
    }
    return(u8Item);
}

/****************************************************************************
 *
 * NAME: bSerialQ_Empty
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC bool_t bSerialQ_Empty(eQueueRef eQueue)
{
    bool_t bResult = FALSE;
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    if(psQueue->u8Count == 0U)
    {
        bResult = TRUE;
    }

    return(bResult);
}

/****************************************************************************
 *
 * NAME: bSerialQ_Full
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PUBLIC bool_t bSerialQ_Full(eQueueRef eQueue)
{
    bool_t bResult = FALSE;
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    if(psQueue->u8Count == MAX_CIRCBUFF_SIZE)
    {
	    bResult = TRUE;
    }

    return(bResult);
}

/****************************************************************************
 *
 * NAME: vSerialQ_Flush
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vSerialQ_Flush(eQueueRef eQueue)
{
    tsCircBuff *psQueue;

    psQueue = (tsCircBuff *)apsQueueList[eQueue]; /* Set pointer to the requested queue */

    psQueue->u8Head  = 0;
    psQueue->u8Tail  = 0;
    psQueue->u8Count = 0;
}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
