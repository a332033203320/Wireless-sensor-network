/****************************************************************************
 *
 * MODULE:             serial.h
 *
 * COMPONENT:          $RCSfile: serial.h,v $
 *
 * VERSION:            $Name: JN-AN-1005-1v7 $
 *
 * REVISION:           $Revision: 1.1 $
 *
 * DATED:              $Date: 2006/08/24 14:59:12 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Ian Morris
 *
 * DESCRIPTION
 *
 * CHANGE HISTORY:
 *
 * $Log: serial.h,v $
 * Revision 1.1  2006/08/24 14:59:12  imorr
 * Initial version
 *
 *
 *
 * LAST MODIFIED BY:   $Author: imorr $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 *  (c) Copyright 2000 JENNIC Ltd
 *
 ****************************************************************************/


#ifndef  SERIAL_H_INCLUDED
#define  SERIAL_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

/****************************************************************************/
/***        Include Files                                                 ***/
/****************************************************************************/
#include <jendefs.h>

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
#define CR_CHAR	  0x0DU
#define LF_CHAR	  0x0AU

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/
PUBLIC void vSerial_Init(void);
PUBLIC void vSerial_TxChar(uint8 u8Chr);
PUBLIC void vSerial_TxString(const uint8 *ps);
PUBLIC int16 i16Serial_RxChar(void);
PUBLIC void vSerialRxString(uint8 *ps);

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

#if defined __cplusplus
}
#endif

#endif  /* SERIAL_H_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


