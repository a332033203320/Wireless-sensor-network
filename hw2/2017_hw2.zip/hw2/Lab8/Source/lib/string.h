#ifndef  STRING_H_INCLUDED
#define  STRING_H_INCLUDED

int strncmp(const char * cs,const char * ct,unsigned int count);
char * strncat(char *dest, const char *src, unsigned int count);
char * strncpy(char *dest, const char *src, unsigned int count);
unsigned int strlen(const char *s);

#endif
