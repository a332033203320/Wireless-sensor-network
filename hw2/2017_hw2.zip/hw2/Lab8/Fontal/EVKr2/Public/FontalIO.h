/*****************************************************************************
 *
 * MODULE:		Fontal Technology Inc. Evaluation Board Library
 * VERSION:		$Name:  $
 * REVISION:		$Revision: 1.1.1.1 $
 * DATED:		2006/11/28
 * AUTHOR:           Tony Lu
 * DESCRIPTION:
 * 	Macros to make it easier to read buttons on demo boards
 * LAST MODIFIED BY:    $Author: isaac_tung $
 * LAST MODIFIED DATE: $Date: 2007/02/02 03:01:12 $
 *
 ****************************************************************************
 *
 *  (c) Fontal Technology Inc. 2006
 *
 ****************************************************************************/


#ifndef _FontalIO_H
#define _FontalIO_H
#include <jendefs.h>
//Define Fontal Uart BaudRate
#define FtUartRate4800 E_AHI_UART_RATE_4800
#define FtUartRate9600 E_AHI_UART_RATE_9600
#define FtUartRate19200 E_AHI_UART_RATE_19200
#define FtUartRate38400 E_AHI_UART_RATE_38400
#define FtUartRate76800 E_AHI_UART_RATE_76800
#define FtUartRate115200 E_AHI_UART_RATE_115200

//Initialize
void FtIO_UartInit(uint8 u8PortNumber, uint8 FtUartRate);
void	FtIO_UartWrite(uint8 PortNumber,uint8 *pdata, uint8 length);
void	FtIO_UartPrint(uint8 PortNumber,const char *str);
uint8 FtIO_UartRead(uint8 PortNumber,uint8 *pdata, uint8 length);
void	FtIO_UartDisable(uint8 PortNumber);

//Fontal Support only one LED
void FtIO_LedInit(void);
void FtIO_LedOn(uint32 bitmap);
void FtIO_LedOff(uint32 bitmap);
void FtIO_LedToggle(uint32 bitmap);

void FtIO_ButtonInit(void);
bool_t FtIO_ButtonPressed(uint8 u8ButtonNumber);

void FtIO_WatchDogInit(void);
void FtIO_WatchDogTrigger(void);

#define BUTTON0 (1<<12)
#define BUTTON1 (1<<10)

#define btn_init() \
		{ \
			vAHI_DioSetDirection(BUTTON0 | BUTTON1, 0); \
			vAHI_DioSetPullup(BUTTON0 | BUTTON1, 0); \
			vAHI_DioInterruptEdge(0, BUTTON0 | BUTTON1); \
			vAHI_DioInterruptEnable(BUTTON0 | BUTTON1, 0); \
		}

#define btn_pressed(bitmap) \
		!(bitmap & u32AHI_DioReadInput())

#define uartio_init(u8Baudrate) \
	FtIO_UartInit(0,u8Baudrate)
#define uartio_write(pdata,length) \
	FtIO_UartWrite(0,pdata,length)
#define uartio_print(str) \
	FtIO_UartPrint(0,str)
#define uartio_read(pdata,length) \
	FtIO_UartRead(0,pdata,length)

//Fontal Module Platform LED set to DIO8
#define LED0	(1 << 8)
#define LED1  (1<<9)
#define LED_ALL (LED0|LED1)

#define led_init() \
		FtIO_LedInit()

#define led_on(bitmap) \
			FtIO_LedOn(bitmap)

#define led_off(bitmap) \
			FtIO_LedOff(bitmap)

#define led_toggle(bitmap)\
			FtIO_LedToggle(bitmap)
#endif

