/*****************************************************************************
 *
 * MODULE:		Fontal Technology Inc. Evaluation Board Library
 * VERSION:		$Name:  $
 * REVISION:		$Revision: 1.1.1.1 $
 * DATED:		2006/11/28
 * AUTHOR:           Tony Lu
 * DESCRIPTION:
 * 	Macros to make it easier to set the watch dog
 * LAST MODIFIED BY:    $Author: isaac_tung $
 * LAST MODIFIED DATE: $Date: 2007/02/02 03:01:12 $
 *
 ****************************************************************************
 *
 *  (c) Fontal Technology Inc. 2007
 *
 ****************************************************************************/


#ifndef _FontalWTD_H
#define _FontalWTD_H
#include <jendefs.h>

#define WDT (1 << 13)


#define wdt_init() \
		vAHI_DioSetDirection(0,WDT)

#define wdt_ResetState() \
    		FtIO_LedToggle(WDT)

#endif

