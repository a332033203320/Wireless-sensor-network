/*****************************************************************************
 *
 * MODULE:		Fontal Technology Inc. Evaluation Board Library
 * VERSION:		$Name:  $
 * REVISION:		$Revision: 1.1.1.1 $
 * DATED:		2006/11/28
 * AUTHOR:           Tony Lu
 * DESCRIPTION:
 * 	Macros to make it easier to set the watch dog
 * LAST MODIFIED BY:    $Author: isaac_tung $
 * LAST MODIFIED DATE: $Date: 2007/02/02 03:01:12 $
 *
 ****************************************************************************
 *
 *  (c) Fontal Technology Inc. 2007
 *
 ****************************************************************************/


#ifndef _FontalWTD_H
#define _FontalWTD_H
#include <jendefs.h>
#include "FontalLED.h"

#define TRIGGER (1 << 16)
#define TRIGGER_TICK ((16*1000*1000)/10)

#define tgr_init() \
		vAHI_DioSetDirection(0,TRIGGER)

#define tgr_send() \
    		led_toggle(TRIGGER)

#endif

