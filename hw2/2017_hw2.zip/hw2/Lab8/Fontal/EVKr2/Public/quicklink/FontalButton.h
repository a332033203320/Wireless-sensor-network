/*****************************************************************************
 *
 * MODULE:		Fontal Technology Inc. Evaluation Board Library
 * VERSION:		$Name:  $
 * REVISION:		$Revision: 1.1.1.1 $
 * DATED:		2006/11/28
 * AUTHOR:           Tony Lu
 * DESCRIPTION:
 * 	Macros to make it easier to read buttons on demo boards
 * LAST MODIFIED BY:    $Author: isaac_tung $
 * LAST MODIFIED DATE: $Date: 2007/02/02 03:01:12 $
 *
 ****************************************************************************
 *
 *  (c) Fontal Technology Inc. 2007
 *
 ****************************************************************************/


#ifndef _FontalBUTTON_H
#define _FontalBUTTON_H
#include <jendefs.h>

#define BUTTON0 (1<<10)
#define BUTTON1 (1<<12)

#define btn_init() \
		{ \
			vAHI_DioSetDirection(BUTTON0 | BUTTON1, 0); \
			vAHI_DioSetPullup(BUTTON0 | BUTTON1, 0); \
			vAHI_DioInterruptEdge(0, BUTTON0 | BUTTON1); \
			vAHI_DioInterruptEnable(BUTTON0 | BUTTON1, 0); \
		}

#define btn_pressed(bitmap) \
		!(bitmap & u32AHI_DioReadInput())


#endif


