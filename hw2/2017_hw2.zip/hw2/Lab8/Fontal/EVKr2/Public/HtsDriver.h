/*****************************************************************************
 *
 * MODULE:              Driver for Sensirion SHT1x humidity and temp sensor
 *
 * COMPONENT:           HtsDriver.h,v
 *
 * VERSION:             JN-SW-4026-SDKwithIDE-1v1
 *
 * REVISION:            1.1
 *
 * DATED:               2007/02/19 13:20:25
 *
 * STATUS:              Exp
 *
 * AUTHOR:              CJG
 *
 * DESCRIPTION:
 * Provides API for driving Sensirion SHT1x humidity and temp sensor.
 *
 * LAST MODIFIED BY:    lmitch
 *                      $Modtime: $
 *
 ****************************************************************************
 *
 *  (c) Copyright JENNIC Ltd 2005
 *
 ****************************************************************************/

#ifndef  HUM_SHT1x_INCLUDED
#define  HUM_SHT1x_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

/****************************************************************************/
/***        Include Files                                                 ***/
/****************************************************************************/
#include "jendefs.h"

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/

#define HTS_DATA_DIO_BIT_MASK (1 << 15)
#define HTS_CLK_DIO_BIT_MASK  (1 << 14)

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/
PUBLIC void   vHTSreset(void);
PUBLIC void   vHTSstartReadTemp(void);
PUBLIC uint16 u16HTSreadTempResult(void);
PUBLIC void   vHTSstartReadHumidity(void);
PUBLIC uint16 u16HTSreadHumidityResult(void);

PUBLIC uint16 u16ReadMeasurementResult(void);


/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

#if defined __cplusplus
}
#endif

#endif  /* HUM_SHT1x_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/

/*  JN-SW-4026-SDKwithIDE-1v1 Friday February 23 15:55:55 GMT 2007 */ 
