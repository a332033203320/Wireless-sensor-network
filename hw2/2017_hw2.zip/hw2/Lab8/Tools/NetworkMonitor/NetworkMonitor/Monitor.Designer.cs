﻿namespace NetworkMonitor
{
    partial class Monitor
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Monitor));
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Serial = new System.IO.Ports.SerialPort(this.components);
            this.Stauts = new System.Windows.Forms.StatusStrip();
            this.field_connected = new System.Windows.Forms.ToolStripStatusLabel();
            this.field_serialstate = new System.Windows.Forms.ToolStripStatusLabel();
            this.field_lastcommand = new System.Windows.Forms.ToolStripStatusLabel();
            this.TickTimer = new System.Windows.Forms.Timer(this.components);
            this.field_myaddress = new System.Windows.Forms.TextBox();
            this.field_parentaddress = new System.Windows.Forms.TextBox();
            this.field_humidity = new System.Windows.Forms.TextBox();
            this.field_temperature = new System.Windows.Forms.TextBox();
            this.field_dest = new System.Windows.Forms.TextBox();
            this.field_payload = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.field_packet = new System.Windows.Forms.TextBox();
            this.NeighborList = new System.Windows.Forms.ListView();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.RouteTable = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.field_lastupdate = new System.Windows.Forms.Label();
            this.field_displaynode = new System.Windows.Forms.ComboBox();
            this.btn_displaymode = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MainMenu.SuspendLayout();
            this.Stauts.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainMenu
            // 
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.actionsToolStripMenuItem,
            this.toolsToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(574, 25);
            this.MainMenu.TabIndex = 0;
            this.MainMenu.Text = "MainMenu";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // actionsToolStripMenuItem
            // 
            this.actionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToolStripMenuItem,
            this.disconnectToolStripMenuItem});
            this.actionsToolStripMenuItem.Name = "actionsToolStripMenuItem";
            this.actionsToolStripMenuItem.Size = new System.Drawing.Size(67, 21);
            this.actionsToolStripMenuItem.Text = "Actions";
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(54, 21);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // Serial
            // 
            this.Serial.BaudRate = 38400;
            this.Serial.StopBits = System.IO.Ports.StopBits.Two;
            // 
            // Stauts
            // 
            this.Stauts.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.field_connected,
            this.field_serialstate,
            this.field_lastcommand});
            this.Stauts.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.Stauts.Location = new System.Drawing.Point(0, 430);
            this.Stauts.Name = "Stauts";
            this.Stauts.Size = new System.Drawing.Size(574, 22);
            this.Stauts.TabIndex = 1;
            this.Stauts.Text = "Stauts";
            // 
            // field_connected
            // 
            this.field_connected.AutoSize = false;
            this.field_connected.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.field_connected.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.field_connected.Name = "field_connected";
            this.field_connected.Size = new System.Drawing.Size(100, 17);
            this.field_connected.Text = "Disconnected";
            // 
            // field_serialstate
            // 
            this.field_serialstate.AutoSize = false;
            this.field_serialstate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.field_serialstate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.field_serialstate.Name = "field_serialstate";
            this.field_serialstate.Size = new System.Drawing.Size(250, 17);
            // 
            // field_lastcommand
            // 
            this.field_lastcommand.AutoSize = false;
            this.field_lastcommand.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.field_lastcommand.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.field_lastcommand.Name = "field_lastcommand";
            this.field_lastcommand.Size = new System.Drawing.Size(200, 17);
            this.field_lastcommand.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            // 
            // TickTimer
            // 
            this.TickTimer.Enabled = true;
            this.TickTimer.Interval = 1000;
            this.TickTimer.Tick += new System.EventHandler(this.TickTimer_Tick);
            // 
            // field_myaddress
            // 
            this.field_myaddress.Location = new System.Drawing.Point(106, 50);
            this.field_myaddress.Name = "field_myaddress";
            this.field_myaddress.ReadOnly = true;
            this.field_myaddress.Size = new System.Drawing.Size(80, 22);
            this.field_myaddress.TabIndex = 2;
            this.field_myaddress.Text = "00000";
            this.field_myaddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // field_parentaddress
            // 
            this.field_parentaddress.Location = new System.Drawing.Point(106, 78);
            this.field_parentaddress.Name = "field_parentaddress";
            this.field_parentaddress.ReadOnly = true;
            this.field_parentaddress.Size = new System.Drawing.Size(80, 22);
            this.field_parentaddress.TabIndex = 3;
            this.field_parentaddress.Text = "00000";
            this.field_parentaddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // field_humidity
            // 
            this.field_humidity.Location = new System.Drawing.Point(106, 189);
            this.field_humidity.Name = "field_humidity";
            this.field_humidity.ReadOnly = true;
            this.field_humidity.Size = new System.Drawing.Size(80, 22);
            this.field_humidity.TabIndex = 4;
            this.field_humidity.Text = "00000";
            this.field_humidity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // field_temperature
            // 
            this.field_temperature.Location = new System.Drawing.Point(106, 161);
            this.field_temperature.Name = "field_temperature";
            this.field_temperature.ReadOnly = true;
            this.field_temperature.Size = new System.Drawing.Size(80, 22);
            this.field_temperature.TabIndex = 4;
            this.field_temperature.Text = "00000";
            this.field_temperature.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // field_dest
            // 
            this.field_dest.Location = new System.Drawing.Point(146, 255);
            this.field_dest.Name = "field_dest";
            this.field_dest.Size = new System.Drawing.Size(40, 22);
            this.field_dest.TabIndex = 5;
            this.field_dest.Text = "00001";
            this.field_dest.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // field_payload
            // 
            this.field_payload.Location = new System.Drawing.Point(246, 255);
            this.field_payload.Name = "field_payload";
            this.field_payload.Size = new System.Drawing.Size(235, 22);
            this.field_payload.TabIndex = 6;
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(487, 253);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 23);
            this.btn_submit.TabIndex = 7;
            this.btn_submit.Text = "Send";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // field_packet
            // 
            this.field_packet.AcceptsReturn = true;
            this.field_packet.Location = new System.Drawing.Point(12, 282);
            this.field_packet.Multiline = true;
            this.field_packet.Name = "field_packet";
            this.field_packet.ReadOnly = true;
            this.field_packet.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.field_packet.Size = new System.Drawing.Size(550, 137);
            this.field_packet.TabIndex = 8;
            this.field_packet.TabStop = false;
            // 
            // NeighborList
            // 
            this.NeighborList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4});
            this.NeighborList.Location = new System.Drawing.Point(198, 38);
            this.NeighborList.Name = "NeighborList";
            this.NeighborList.Size = new System.Drawing.Size(99, 211);
            this.NeighborList.TabIndex = 9;
            this.NeighborList.TabStop = false;
            this.NeighborList.UseCompatibleStateImageBehavior = false;
            this.NeighborList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Neighbors";
            this.columnHeader4.Width = 80;
            // 
            // RouteTable
            // 
            this.RouteTable.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.RouteTable.Location = new System.Drawing.Point(303, 38);
            this.RouteTable.Name = "RouteTable";
            this.RouteTable.Size = new System.Drawing.Size(259, 211);
            this.RouteTable.TabIndex = 10;
            this.RouteTable.TabStop = false;
            this.RouteTable.UseCompatibleStateImageBehavior = false;
            this.RouteTable.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Destination";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Next Hop";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Time To Live";
            this.columnHeader3.Width = 80;
            // 
            // field_lastupdate
            // 
            this.field_lastupdate.AutoSize = true;
            this.field_lastupdate.Location = new System.Drawing.Point(34, 221);
            this.field_lastupdate.Name = "field_lastupdate";
            this.field_lastupdate.Size = new System.Drawing.Size(66, 12);
            this.field_lastupdate.TabIndex = 11;
            this.field_lastupdate.Text = "Last Update :";
            // 
            // field_displaynode
            // 
            this.field_displaynode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_displaynode.FormattingEnabled = true;
            this.field_displaynode.Location = new System.Drawing.Point(106, 106);
            this.field_displaynode.Name = "field_displaynode";
            this.field_displaynode.Size = new System.Drawing.Size(80, 20);
            this.field_displaynode.TabIndex = 12;
            // 
            // btn_displaymode
            // 
            this.btn_displaymode.Location = new System.Drawing.Point(106, 132);
            this.btn_displaymode.Name = "btn_displaymode";
            this.btn_displaymode.Size = new System.Drawing.Size(80, 23);
            this.btn_displaymode.TabIndex = 13;
            this.btn_displaymode.Text = "Display";
            this.btn_displaymode.UseVisualStyleBackColor = true;
            this.btn_displaymode.Click += new System.EventHandler(this.btn_displaymode_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "Address :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "Parent Address :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 12);
            this.label3.TabIndex = 16;
            this.label3.Text = "Temperature :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 12);
            this.label4.TabIndex = 17;
            this.label4.Text = "Humidity :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "PACKET    Destination :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(192, 261);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 12);
            this.label6.TabIndex = 19;
            this.label6.Text = "Payload :";
            // 
            // Monitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 452);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_displaymode);
            this.Controls.Add(this.field_displaynode);
            this.Controls.Add(this.field_lastupdate);
            this.Controls.Add(this.RouteTable);
            this.Controls.Add(this.NeighborList);
            this.Controls.Add(this.field_packet);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.field_payload);
            this.Controls.Add(this.field_dest);
            this.Controls.Add(this.field_temperature);
            this.Controls.Add(this.field_humidity);
            this.Controls.Add(this.field_parentaddress);
            this.Controls.Add(this.field_myaddress);
            this.Controls.Add(this.Stauts);
            this.Controls.Add(this.MainMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MainMenu;
            this.MaximizeBox = false;
            this.Name = "Monitor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sensor Network Monitor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Monitor_FormClosing);
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.Stauts.ResumeLayout(false);
            this.Stauts.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.IO.Ports.SerialPort Serial;
        private System.Windows.Forms.StatusStrip Stauts;
        private System.Windows.Forms.ToolStripStatusLabel field_connected;
        private System.Windows.Forms.ToolStripStatusLabel field_serialstate;
        private System.Windows.Forms.Timer TickTimer;
        private System.Windows.Forms.TextBox field_myaddress;
        private System.Windows.Forms.TextBox field_parentaddress;
        private System.Windows.Forms.TextBox field_humidity;
        private System.Windows.Forms.TextBox field_temperature;
        private System.Windows.Forms.ToolStripStatusLabel field_lastcommand;
        private System.Windows.Forms.TextBox field_dest;
        private System.Windows.Forms.TextBox field_payload;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.TextBox field_packet;
        private System.Windows.Forms.ListView NeighborList;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ListView RouteTable;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label field_lastupdate;
        private System.Windows.Forms.ComboBox field_displaynode;
        private System.Windows.Forms.Button btn_displaymode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripMenuItem actionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
    }
}

