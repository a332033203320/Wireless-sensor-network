﻿namespace NetworkMonitor
{
    partial class Settings
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tab_SerialPort = new System.Windows.Forms.TabPage();
            this.field_bits = new System.Windows.Forms.ComboBox();
            this.field_baud = new System.Windows.Forms.ComboBox();
            this.field_port = new System.Windows.Forms.ComboBox();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.field_parity = new System.Windows.Forms.ComboBox();
            this.field_stop = new System.Windows.Forms.ComboBox();
            this.field_flow = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tab_SerialPort.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tab_SerialPort);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(237, 201);
            this.tabControl.TabIndex = 0;
            // 
            // tab_SerialPort
            // 
            this.tab_SerialPort.Controls.Add(this.label6);
            this.tab_SerialPort.Controls.Add(this.label5);
            this.tab_SerialPort.Controls.Add(this.label4);
            this.tab_SerialPort.Controls.Add(this.label3);
            this.tab_SerialPort.Controls.Add(this.label2);
            this.tab_SerialPort.Controls.Add(this.label1);
            this.tab_SerialPort.Controls.Add(this.field_flow);
            this.tab_SerialPort.Controls.Add(this.field_stop);
            this.tab_SerialPort.Controls.Add(this.field_parity);
            this.tab_SerialPort.Controls.Add(this.field_bits);
            this.tab_SerialPort.Controls.Add(this.field_baud);
            this.tab_SerialPort.Controls.Add(this.field_port);
            this.tab_SerialPort.Location = new System.Drawing.Point(4, 21);
            this.tab_SerialPort.Name = "tab_SerialPort";
            this.tab_SerialPort.Padding = new System.Windows.Forms.Padding(3);
            this.tab_SerialPort.Size = new System.Drawing.Size(229, 176);
            this.tab_SerialPort.TabIndex = 0;
            this.tab_SerialPort.Text = "Serial Port";
            this.tab_SerialPort.UseVisualStyleBackColor = true;
            // 
            // field_bits
            // 
            this.field_bits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_bits.FormattingEnabled = true;
            this.field_bits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.field_bits.Location = new System.Drawing.Point(94, 66);
            this.field_bits.Name = "field_bits";
            this.field_bits.Size = new System.Drawing.Size(121, 20);
            this.field_bits.TabIndex = 2;
            // 
            // field_baud
            // 
            this.field_baud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_baud.FormattingEnabled = true;
            this.field_baud.Items.AddRange(new object[] {
            "110",
            "300",
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.field_baud.Location = new System.Drawing.Point(94, 40);
            this.field_baud.Name = "field_baud";
            this.field_baud.Size = new System.Drawing.Size(121, 20);
            this.field_baud.TabIndex = 1;
            // 
            // field_port
            // 
            this.field_port.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_port.FormattingEnabled = true;
            this.field_port.Location = new System.Drawing.Point(94, 14);
            this.field_port.Name = "field_port";
            this.field_port.Size = new System.Drawing.Size(121, 20);
            this.field_port.TabIndex = 0;
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(174, 219);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 1;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(93, 219);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 2;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // field_parity
            // 
            this.field_parity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_parity.FormattingEnabled = true;
            this.field_parity.Location = new System.Drawing.Point(94, 92);
            this.field_parity.Name = "field_parity";
            this.field_parity.Size = new System.Drawing.Size(121, 20);
            this.field_parity.TabIndex = 3;
            // 
            // field_stop
            // 
            this.field_stop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_stop.FormattingEnabled = true;
            this.field_stop.Location = new System.Drawing.Point(94, 118);
            this.field_stop.Name = "field_stop";
            this.field_stop.Size = new System.Drawing.Size(121, 20);
            this.field_stop.TabIndex = 4;
            // 
            // field_flow
            // 
            this.field_flow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.field_flow.FormattingEnabled = true;
            this.field_flow.Location = new System.Drawing.Point(94, 144);
            this.field_flow.Name = "field_flow";
            this.field_flow.Size = new System.Drawing.Size(121, 20);
            this.field_flow.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "Port : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "Buad Rate : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "Data Bits : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "Parity Check : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "Stop Bits : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "Flow Control : ";
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 253);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.tabControl.ResumeLayout(false);
            this.tab_SerialPort.ResumeLayout(false);
            this.tab_SerialPort.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tab_SerialPort;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
        public System.Windows.Forms.ComboBox field_port;
        public System.Windows.Forms.ComboBox field_baud;
        public System.Windows.Forms.ComboBox field_bits;
        public System.Windows.Forms.ComboBox field_parity;
        public System.Windows.Forms.ComboBox field_stop;
        public System.Windows.Forms.ComboBox field_flow;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}