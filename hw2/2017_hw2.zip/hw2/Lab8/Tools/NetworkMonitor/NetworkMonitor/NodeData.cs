﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetworkMonitor
{
    public class NodeData
    {
        public DateTime LastUpdate;

        public uint MyAddress;
        public uint ParentAddress;

        public int Humidity;
        public int Temperature;

        public String[] Neighbors;
        public Dictionary<uint, uint> RouteTable;

        public NodeData()
        {
            ResetData();
        }

        public void ResetData()
        {
            LastUpdate = DateTime.Today;

            MyAddress = 0;
            ParentAddress = 0;

            Humidity = 0;
            Temperature = 0;

            Neighbors = new String[] {};
            RouteTable = new Dictionary<uint, uint>();
        }
    }
}
