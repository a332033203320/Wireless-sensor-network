﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace NetworkMonitor
{
    public partial class Monitor : Form
    {
        Thread SerialThread;
        Dictionary<uint, NodeData> Nodes;
        Char[] CRLF = new Char[] { '\r', '\n'};
        NodeData CurrentNode;
        bool DisplayMode;

        public Monitor()
        {
            InitializeComponent();

            CurrentNode = new NodeData();
            Nodes = new Dictionary<uint, NodeData>();
            DisplayMode = false;

            //處理Serial Port Data的Thread
            SerialThread = new Thread(new ThreadStart(SerialThreadProcessor));
            //Serial.NewLine = new String(new Char[] {(char)(0x0d)});

            setSerialStatus();
            switchSerial(1);
        }

        #region Events

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings s = new Settings();

            //設定值域
            s.field_port.Items.AddRange(SerialPort.GetPortNames());
            s.field_parity.Items.AddRange(Enum.GetNames(typeof(Parity)));
            s.field_stop.Items.AddRange(Enum.GetNames(typeof(StopBits)));
            s.field_stop.Items.Remove("None");
            s.field_flow.Items.AddRange(Enum.GetNames(typeof(Handshake)));

            //設定目前值
            s.field_port.Text = Serial.PortName;
            s.field_baud.Text = Serial.BaudRate.ToString();
            s.field_bits.Text = Serial.DataBits.ToString();
            s.field_parity.Text = Serial.Parity.ToString();
            s.field_stop.Text = Serial.StopBits.ToString();
            s.field_flow.Text = Serial.Handshake.ToString();

            //設定更新後的值
            if (s.ShowDialog() == DialogResult.OK)
            {
                switchSerial(0);

                try
                {
                    Serial.PortName = s.field_port.Text;
                    Serial.BaudRate = Int32.Parse(s.field_baud.Text);
                    Serial.DataBits = Int32.Parse(s.field_bits.Text);
                    Serial.Parity = (Parity)Enum.Parse(((new Parity()).GetType()), s.field_parity.Text);
                    Serial.StopBits = (StopBits)Enum.Parse(((new StopBits()).GetType()), s.field_stop.Text);
                    Serial.Handshake = (Handshake)Enum.Parse(((new Handshake()).GetType()), s.field_flow.Text);
                    setSerialStatus();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }

                switchSerial(1);
            }
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            switchSerial(1);
        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            switchSerial(0);
        }

        private void Monitor_FormClosing(object sender, FormClosingEventArgs e)
        {
            switchSerial(0);
        }

        private void btn_displaymode_Click(object sender, EventArgs e)
        {
            if (field_displaynode.Text != CurrentNode.MyAddress.ToString("d5") && field_displaynode.Text != "")
            {
                DisplayMode = true;
                updateDisplay();
            }
            else DisplayMode = false;

            if (field_displaynode.Text != "")
            {
                String dest = field_displaynode.Text;
                String src = CurrentNode.MyAddress.ToString("d5");

                Serial.WriteLine("DUMPHT " + src + " " + dest + "\r\n");
                Serial.WriteLine("DUMPROUTE " + src + " " + dest + "\r\n");
                Serial.WriteLine("DUMPNBR " + src + " " + dest + "\r\n");
            }
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            uint src = CurrentNode.MyAddress;
            uint dest = 1;

            try
            {
                dest = UInt32.Parse(field_dest.Text);
            }
            catch
            {
                MessageBox.Show("Desitination address format is now allowed.", "Packet Format Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (field_payload.Text == "")
            {
                MessageBox.Show("Empty packet payload area is now allowed.", "Packet Format Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            String payload = "PACKET " + src.ToString("d5") + " " + dest.ToString("d5") + " " + field_payload.Text.Replace(' ', '_') + "\r\n";
        }

        private int timetodump = 3, timetonodeaddr = 3;
        private void TickTimer_Tick(object sender, EventArgs e)
        {

            //定期更新可以顯示的Node
            String tmp_displaynode = field_displaynode.Text;
            field_displaynode.Items.Clear();
            foreach (NodeData node in Nodes.Values)
                field_displaynode.Items.Add(node.MyAddress.ToString("d5"));
            if (DisplayMode)
                field_displaynode.Text = tmp_displaynode;
            else field_displaynode.Text = CurrentNode.MyAddress.ToString("d5");

            //更新顯示內容
            updateDisplay();

            //定時更新所與連接Node的資訊
            if (Serial.IsOpen)
            {
                
                if (CurrentNode.MyAddress != 0 && timetodump-- <= 0)
                {
                    timetodump = 10;
                    String dest = CurrentNode.MyAddress.ToString("d5");

                    //Serial.WriteLine("DUMPHT_R " + dest + " " + dest + "\r\n\0");
                    //Serial.WriteLine("DUMPROUTE_R " + dest + " " + dest + "\r\n\0");
                    //Serial.WriteLine("DUMPNBR_R " + dest + " " + dest + " \r");
                    return;
                }

                if (timetonodeaddr-- <= 0)
                {
                    timetonodeaddr = 5;
                    Serial.WriteLine("NOWADDR \r\n");
                }
            }
        }

        #endregion

        #region Threads

        private void SerialThreadProcessor()
        {
            String command;
            String[] command_token;
                      
            try
            {
                while (true)
                {
                    command = Serial.ReadLine().Trim(CRLF).Trim();

                    if (command.Length == 0)
                        continue;
                    //if(command.Contains("MESSAGE:"))
                    //field_packet.Text = this.ToHEX(command) + "\r\n" + field_packet.Text;
                    field_packet.Text = command + "\r\n" + field_packet.Text;
                    field_lastcommand.Text = command;
                    command_token = command.Split((new Char[] { ' ' }), StringSplitOptions.RemoveEmptyEntries);
                    try
                    {

                        if (command_token[0] == "NOWADDR" && command_token.Length ==3)
                        {
                            uint myaddress = UInt32.Parse(command_token[1]);
                            uint parentaddress = UInt32.Parse(command_token[2]);

                            if (!Nodes.ContainsKey(myaddress))
                                Nodes.Add(myaddress, new NodeData());

                            Nodes.TryGetValue(myaddress, out CurrentNode);

                            CurrentNode.MyAddress = myaddress;
                            CurrentNode.ParentAddress = parentaddress;
                        }

                        if (command_token[0] == "PACKET")
                            field_packet.Text = "PA:" +command_token[1] + " : " + command_token[3].Replace('_', ' ') + "asdf\r\n" + field_packet.Text;

                        if (command_token[0] == "DUMPNBR_R")
                        {
                            uint src = UInt32.Parse(command_token[1]);
                            uint dest = UInt32.Parse(command_token[2]);

                            NodeData TargetNode;

                            if (!Nodes.ContainsKey(src))
                                Nodes.Add(src, new NodeData());

                            Nodes.TryGetValue(src, out TargetNode);
                            TargetNode.MyAddress = src;

                            TargetNode.Neighbors = command_token[3].Split((new Char[] { '|' }), StringSplitOptions.RemoveEmptyEntries);

                        }

                        if (command_token[0] == "DUMPROUTE_R")
                        {
                            uint src = UInt32.Parse(command_token[1]);
                            uint dest = UInt32.Parse(command_token[2]);

                            NodeData TargetNode;

                            if (!Nodes.ContainsKey(src))
                                Nodes.Add(src, new NodeData());

                            Nodes.TryGetValue(src, out TargetNode);
                            TargetNode.MyAddress = src;

                            TargetNode.RouteTable.Clear();
                            String[] Routes = command_token[3].Split((new Char[] { '|' }), StringSplitOptions.RemoveEmptyEntries);
                            foreach (String Route in Routes)
                            {
                                String[] r_token = Route.Split((new Char[] { ':' }), StringSplitOptions.RemoveEmptyEntries);
                                TargetNode.RouteTable.Add(UInt32.Parse(r_token[0]), UInt32.Parse(r_token[1]));
                            }

                        }

                        if (command_token[0] == "DUMPHT_R")
                        {
                            uint src = UInt32.Parse(command_token[1]);
                            uint dest = UInt32.Parse(command_token[2]);


                            NodeData TargetNode;

                            if (!Nodes.ContainsKey(src))
                                Nodes.Add(src, new NodeData());

                            Nodes.TryGetValue(src, out TargetNode);
                            TargetNode.MyAddress = src;

                            String[] HT = command_token[3].Split((new Char[] { '|' }), StringSplitOptions.RemoveEmptyEntries);
                            TargetNode.Humidity = Int32.Parse(HT[0]);
                            TargetNode.Temperature = Int32.Parse(HT[1]);

                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
            catch (Exception) { }
        }

        #endregion

        #region Layout Methods

        private void updateDisplay()
        {            
            field_myaddress.Text = CurrentNode.MyAddress.ToString("d5");
            field_parentaddress.Text = CurrentNode.ParentAddress.ToString("d5");

            NodeData TargetNode;
            if (!DisplayMode)
                TargetNode = CurrentNode;
            else Nodes.TryGetValue(UInt32.Parse(field_displaynode.Text),out TargetNode);

            field_temperature.Text = TargetNode.Temperature.ToString("d5");
            field_humidity.Text = TargetNode.Humidity.ToString("d5");

            setNeighborList(TargetNode);
            setRouteTable(TargetNode);
        }

        //設定Serial State String
        private void setSerialStatus()
        {
            field_serialstate.Text =  Serial.PortName;
            field_serialstate.Text += "-" + Serial.BaudRate.ToString();
            field_serialstate.Text += "-" + Serial.DataBits.ToString();
            field_serialstate.Text += "-" + Serial.Parity.ToString();
            field_serialstate.Text += "-" + Serial.StopBits.ToString();
            field_serialstate.Text += "-" + Serial.Handshake.ToString();
        }

        //設定Neighbor List
        private void setNeighborList(NodeData TargetNode)
        {
            NeighborList.Items.Clear();
            foreach (String value in TargetNode.Neighbors)
            {
                ListViewItem tmp_nbr = new ListViewItem(value);
                NeighborList.Items.Add(tmp_nbr);
            }
        }

        //設定Route Table
        private void setRouteTable(NodeData TargetNode)
        {
            RouteTable.Items.Clear();

            ListViewItem tmp_route = new ListViewItem(new String[] { TargetNode.MyAddress.ToString("d5"), TargetNode.MyAddress.ToString("d5"), "N.A." }, -1);
            RouteTable.Items.Add(tmp_route);

            foreach (uint dest in TargetNode.RouteTable.Keys)
            {
                uint nexthop;
                TargetNode.RouteTable.TryGetValue(dest, out nexthop);
                tmp_route = new ListViewItem(new String[] { dest.ToString("d5"), nexthop.ToString("d5"), "N.A." }, -1);
                RouteTable.Items.Add(tmp_route);
            }
        }

        private void switchSerial(int state)
        {
            try
            {
                if(state == 0)
                {
                    if (Serial.IsOpen == true)
                    {
                        Thread.Sleep(2);
                        Serial.Close();
                        SerialThread.Abort();
                        field_connected.Text = "Disconnected";
                    }
                }
                else if (state == 1)
                {
                    if (Serial.IsOpen == false)
                    {
                        Thread.Sleep(2);
                        Serial.Open();
                        SerialThread.Abort();
                        SerialThread = new Thread(new ThreadStart(SerialThreadProcessor));
                        SerialThread.Start();
                        field_connected.Text = "Connected";
                    }
                }
                else if (Serial.IsOpen)
                {
                    Thread.Sleep(2);
                    Serial.Close();
                    if (SerialThread.IsAlive)
                        SerialThread.Abort();
                    field_connected.Text = "Disconnected";
                }
                else
                {
                    Thread.Sleep(2);
                    Serial.Open();
                    SerialThread.Abort();
                    SerialThread = new Thread(new ThreadStart(SerialThreadProcessor));
                    SerialThread.Start();
                    field_connected.Text = "Connected";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        private String ToHEX(String str)
        {
            Char[] cs = str.ToCharArray();
            String rtv = "";
            foreach (Char c in cs)
                rtv += "%" + ((uint)c).ToString("x2");

            return rtv;
        }
    }
}